declare interface IMsaltestAdaptiveCardExtensionStrings {
  PropertyPaneDescription: string;
  TitleFieldLabel: string;
  Title: string;
  SubTitle: string;
  PrimaryText: string;
  Description: string;
  QuickViewButton: string;
}

declare module 'MsaltestAdaptiveCardExtensionStrings' {
  const strings: IMsaltestAdaptiveCardExtensionStrings;
  export = strings;
}
