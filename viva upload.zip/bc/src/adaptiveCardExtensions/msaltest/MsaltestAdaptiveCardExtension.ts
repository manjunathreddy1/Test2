import type { IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { BaseAdaptiveCardExtension } from "@microsoft/sp-adaptive-card-extension-base";
import { CardView } from "./cardView/CardView";
import { QuickView } from "./quickView/QuickView";
import { MsaltestPropertyPane } from "./MsaltestPropertyPane";

export interface IMsaltestAdaptiveCardExtensionProps {
  title: string;
}

export interface IMsaltestAdaptiveCardExtensionState {
  response: string;
}

const CARD_VIEW_REGISTRY_ID: string = "Msaltest_CARD_VIEW";
export const QUICK_VIEW_REGISTRY_ID: string = "Msaltest_QUICK_VIEW";

export default class MsaltestAdaptiveCardExtension extends BaseAdaptiveCardExtension<
  IMsaltestAdaptiveCardExtensionProps,
  IMsaltestAdaptiveCardExtensionState
> {
  private _deferredPropertyPane: MsaltestPropertyPane;

  public onInit(): Promise<void> {
    this.state = { response: "Loading.." };

    // registers the card view to be shown in a dashboard
    this.cardNavigator.register(CARD_VIEW_REGISTRY_ID, () => new CardView());
    // registers the quick view to open via QuickView action
    this.quickViewNavigator.register(
      QUICK_VIEW_REGISTRY_ID,
      () => new QuickView()
    );

    return Promise.resolve();
  }

  protected loadPropertyPaneResources(): Promise<void> {
    return import(
      /* webpackChunkName: 'Msaltest-property-pane'*/
      "./MsaltestPropertyPane"
    ).then((component) => {
      this._deferredPropertyPane = new component.MsaltestPropertyPane();
    });
  }

  protected renderCard(): string | undefined {
    return CARD_VIEW_REGISTRY_ID;
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return this._deferredPropertyPane?.getPropertyPaneConfiguration();
  }
}
