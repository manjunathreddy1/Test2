import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
export declare class MsaltestPropertyPane {
    getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=MsaltestPropertyPane.d.ts.map