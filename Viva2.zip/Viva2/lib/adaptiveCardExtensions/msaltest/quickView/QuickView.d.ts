import { ISPFxAdaptiveCard, BaseAdaptiveCardQuickView } from "@microsoft/sp-adaptive-card-extension-base";
import { IMsaltestAdaptiveCardExtensionProps, IMsaltestAdaptiveCardExtensionState } from "../MsaltestAdaptiveCardExtension";
export interface IQuickViewData {
    title: string;
}
export declare class QuickView extends BaseAdaptiveCardQuickView<IMsaltestAdaptiveCardExtensionProps, IMsaltestAdaptiveCardExtensionState, IQuickViewData> {
    onInit(): Promise<void>;
    constructor();
    private loadData;
    get data(): IQuickViewData;
    onAction(action: any): void;
    get template(): ISPFxAdaptiveCard;
}
//# sourceMappingURL=QuickView.d.ts.map