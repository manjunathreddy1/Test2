import { BaseComponentsCardView, ComponentsCardViewParameters, IExternalLinkCardAction, IQuickViewCardAction } from "@microsoft/sp-adaptive-card-extension-base";
import { IMsaltestAdaptiveCardExtensionProps, IMsaltestAdaptiveCardExtensionState } from "../MsaltestAdaptiveCardExtension";
export declare class CardView extends BaseComponentsCardView<IMsaltestAdaptiveCardExtensionProps, IMsaltestAdaptiveCardExtensionState, ComponentsCardViewParameters> {
    get cardViewParameters(): ComponentsCardViewParameters;
    onAction(action: any): void;
    get onCardSelection(): IQuickViewCardAction | IExternalLinkCardAction | undefined;
}
//# sourceMappingURL=CardView.d.ts.map