import {
  ISPFxAdaptiveCard,
  BaseAdaptiveCardQuickView,
} from "@microsoft/sp-adaptive-card-extension-base";
//import * as strings from "MsaltestAdaptiveCardExtensionStrings";
import {
  IMsaltestAdaptiveCardExtensionProps,
  IMsaltestAdaptiveCardExtensionState,
} from "../MsaltestAdaptiveCardExtension";

export interface IQuickViewData {
  title: string;
}

export class QuickView extends BaseAdaptiveCardQuickView<
  IMsaltestAdaptiveCardExtensionProps,
  IMsaltestAdaptiveCardExtensionState,
  IQuickViewData
> {
  public async onInit(): Promise<void> {
    this.loadData();
  }
  constructor() {
    super();
    this.loadData();
  }

  private async loadData() {
    const response = await new Promise<string>((resolve) => {
      setTimeout(() => resolve("2222"), 500);
    });

    this.setState({ response });
  }

  public get data(): IQuickViewData {
    return {
      title: this.state.response,
    };
  }
  public onAction(action: any): void {
    if (action.id === "fetchData") {
    }
  }
  public get template(): ISPFxAdaptiveCard {
    return require("./template/QuickViewTemplate.json");
  }
}
