"use strict";
(self["webpackJsonp_2e1c5194-9b8b-4b97-90ce-57f52f080628_0.0.1"] = self["webpackJsonp_2e1c5194-9b8b-4b97-90ce-57f52f080628_0.0.1"] || []).push([["Msaltest-property-pane"],{

/***/ 365:
/*!*********************************************************************!*\
  !*** ./lib/adaptiveCardExtensions/msaltest/MsaltestPropertyPane.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MsaltestPropertyPane: () => (/* binding */ MsaltestPropertyPane)
/* harmony export */ });
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/sp-property-pane */ 723);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var MsaltestAdaptiveCardExtensionStrings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! MsaltestAdaptiveCardExtensionStrings */ 745);
/* harmony import */ var MsaltestAdaptiveCardExtensionStrings__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(MsaltestAdaptiveCardExtensionStrings__WEBPACK_IMPORTED_MODULE_1__);


var MsaltestPropertyPane = /** @class */ (function () {
    function MsaltestPropertyPane() {
    }
    MsaltestPropertyPane.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: { description: MsaltestAdaptiveCardExtensionStrings__WEBPACK_IMPORTED_MODULE_1__.PropertyPaneDescription },
                    groups: [
                        {
                            groupFields: [
                                (0,_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0__.PropertyPaneTextField)('title', {
                                    label: MsaltestAdaptiveCardExtensionStrings__WEBPACK_IMPORTED_MODULE_1__.TitleFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return MsaltestPropertyPane;
}());



/***/ })

}]);
//# sourceMappingURL=chunk.Msaltest-property-pane.js.map